# MPI Implementation for Game of Life

Comparing sequential implementation with the MPI implementation with 1D and 2D decompositions of the Game of Life simulation.
